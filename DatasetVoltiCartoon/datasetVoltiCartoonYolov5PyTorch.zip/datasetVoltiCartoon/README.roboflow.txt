
bimbi_facce - v1 Age
==============================

This dataset was exported via roboflow.ai on June 24, 2022 at 3:08 PM GMT

It includes 998 images.
Age are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


