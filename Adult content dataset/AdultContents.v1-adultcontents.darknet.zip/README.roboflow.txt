
AdultContents - v1 AdultContents
==============================

This dataset was exported via roboflow.ai on June 30, 2022 at 1:28 PM GMT

It includes 1847 images.
Adult-contents are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


